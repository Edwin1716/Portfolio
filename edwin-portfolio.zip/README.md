# Edwin Geevarughese Portfolio

This is a personal portfolio website built with React. It showcases projects in Tableau, ArcGIS, GitHub, and Power BI.

## Setup

1. Install dependencies:

   ```
   npm install
   ```

2. Run locally:

   ```
   npm start
   ```

## Deployment

You can deploy this site using [Vercel](https://vercel.com) or GitHub Pages.

## Features

- Projects with previews and links
- Education and experience
- Light modern theme
