
import React from 'react';

export default function Portfolio() {
  return (
    <main style={{
      padding: '2rem',
      maxWidth: '960px',
      margin: 'auto',
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, sans-serif',
      color: '#333',
    }}>
      <header style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{
          width: '96px',
          height: '96px',
          borderRadius: '50%',
          backgroundColor: '#ccc',
          margin: '0 auto'
        }}></div>
        <h1 style={{ fontSize: '2rem', marginTop: '1rem' }}>Edwin Geevarughese</h1>
        <p>Data Enthusiast | Systems Engineer | GIS Explorer</p>
      </header>

      <section style={{ marginBottom: '2rem' }}>
        <h2>About Me</h2>
        <p><strong>Education:</strong> B.Tech in Electronics and Communication Engineering, Springboard Data Analytics Bootcamp</p>
        <p><strong>Experience:</strong> Associate Systems Engineer at City of Philadelphia. 5+ years experience in tech support for airport security systems.</p>
        <p><strong>Skills:</strong> Windows OS, Active Directory, Tableau, Power BI, SQL, Python, ArcGIS Pro</p>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h2>Projects</h2>
        <ul>
          <li><a href="https://public.tableau.com/app/profile/edwin_geevarughese/viz/PhiladelphiaAccidentAnalysis" target="_blank">Philadelphia Accident Analysis (Tableau)</a></li>
          <li><a href="https://arcgis.com/apps/dashboard/airport-job-control" target="_blank">Airport GIS Job Control Dashboard (ArcGIS)</a></li>
          <li><a href="https://github.com/edwingeevarughese/data-cleaning-project" target="_blank">Data Cleaning with Python & SQL (GitHub)</a></li>
        </ul>
      </section>

      <section>
        <h2>Contact</h2>
        <p>Email: <a href="mailto:edwin@example.com">edwin@example.com</a></p>
        <p>LinkedIn: <a href="https://linkedin.com/in/edwingeevarughese" target="_blank">linkedin.com/in/edwingeevarughese</a></p>
        <p>GitHub: <a href="https://github.com/edwingeevarughese" target="_blank">github.com/edwingeevarughese</a></p>
      </section>
    </main>
  );
}
